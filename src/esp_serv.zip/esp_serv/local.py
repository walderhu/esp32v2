import socket
import json
import subprocess

# --- HTTP сервер ---
def serve():
    HTML = open("index.html").read()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    port = 8082
    s.bind(("0.0.0.0", port))
    s.listen(1)
    print(f"Открой http://localhost:{port}")
    while True:
        cl, addr = s.accept()
        try:
            req = cl.recv(4096).decode(errors='ignore')
            if req.startswith('POST /press'):
                body = req.split('\r\n\r\n', 1)[-1]
                try:
                    data = json.loads(body)
                    dir = data.get('dir')
                    action = data.get('action')
                    value = data.get('value', None)
                except Exception as e: print("Ошибка JSON:", e)
                cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nOK")
                
            elif req.startswith('GET /misc/'):
                path = req.split(' ', 2)[1][1:]
                try:
                    with open(path, 'rb') as f:
                        content = f.read()
                    if path.endswith('.svg'): ctype = 'image/svg+xml'
                    elif path.endswith('.png'): ctype = 'image/png'
                    elif path.endswith('.jpg') or path.endswith('.jpeg'): ctype = 'image/jpeg'
                    else: ctype = 'application/octet-stream'
                    cl.send(f"HTTP/1.1 200 OK\r\nContent-Type: {ctype}\r\n\r\n".encode())
                    cl.sendall(content)
                except: cl.send(b"HTTP/1.1 404 Not Found\r\n\r\n")
                
            elif req.startswith('GET /style.css'):
                try:
                    css = open('style.css', 'rb').read()
                    cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: text/css; charset=utf-8\r\n\r\n")
                    cl.sendall(css)
                except: cl.send(b"HTTP/1.1 404 Not Found\r\n\r\n")
                    
            elif req.startswith('GET /coords'):
                global X, Y
                try: pass
                except (subprocess.TimeoutExpired, BrokenPipeError) as e:
                    print(f"⚠️ {e}"); return
                cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n")

            else:
                cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n")
                cl.sendall(HTML.encode())
        except Exception as e: print("⚠️  Ошибка:", e)
        finally: cl.close()

if __name__ == "__main__":
    print("✅ ESP инициализирована. Ожидание команд...")
    try: serve()
    except KeyboardInterrupt: pass
