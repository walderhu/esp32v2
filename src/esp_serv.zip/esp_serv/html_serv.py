# ESP32 / WROOM micropython v1.26.1
import network, time
import usocket as socket
import ujson as json

# --- Wi-Fi подключение ---
def connect_wifi(ssid="TP-Link_0D14", password="24827089"):
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    if not sta.isconnected():
        print("Connecting to WiFi...")
        sta.connect(ssid, password)
        t_start = time.ticks_ms()
        while not sta.isconnected():
            if time.ticks_diff(time.ticks_ms(), t_start) > 10000:  # 10 секунд таймаут
                raise Exception("WiFi connect failed")
            time.sleep_ms(100)
    ip = sta.ifconfig()[0]
    print("Wi-Fi connected:", sta.ifconfig())
    return ip

# --- Начальные координаты ---
X = 0.0
Y = 0.0

# --- HTTP сервер ---
def serve(ip, port=8082):
    try:
        with open("index.html") as f:
            HTML = f.read()
    except:
        HTML = "<h1>index.html not found</h1>"

    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((ip, port))
    s.listen(1)
    print(f"🌐 Web server running at: http://{ip}:{port}/")

    while True:
        cl, addr = s.accept()
        try:
            req = cl.recv(1024).decode("utf-8")  # ESP32 может не принять 4096
            if not req:
                cl.close()
                continue

            # --- POST /press ---
            if req.startswith("POST /press"):
                body = req.split("\r\n\r\n", 1)[-1]
                try:
                    data = json.loads(body)
                    dir = data.get("dir")
                    action = data.get("action")
                    value = data.get("value", None)
                    print("Команда:", dir, action, value)
                except Exception as e:
                    print("Ошибка JSON:", e)
                cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nOK")

            # --- GET /misc/... ---
            elif req.startswith("GET /misc/"):
                path = req.split(" ")[1][1:]
                try:
                    content = open(path, "rb").read()
                    if path.endswith(".svg"):
                        ctype = "image/svg+xml"
                    elif path.endswith(".png"):
                        ctype = "image/png"
                    elif path.endswith(".jpg") or path.endswith(".jpeg"):
                        ctype = "image/jpeg"
                    else:
                        ctype = "application/octet-stream"
                    cl.send("HTTP/1.1 200 OK\r\nContent-Type: {}\r\n\r\n".format(ctype).encode())
                    cl.sendall(content)
                except:
                    cl.send(b"HTTP/1.1 404 Not Found\r\n\r\n")

            # --- GET /style.css ---
            elif req.startswith("GET /style.css"):
                try:
                    with open("style.css", "rb") as f:
                        css = f.read()
                    cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: text/css\r\n\r\n")
                    cl.sendall(css)
                except:
                    cl.send(b"HTTP/1.1 404 Not Found\r\n\r\n")

            # --- GET /coords ---
            elif req.startswith("GET /coords"):
                global X, Y
                resp = json.dumps({"x": X, "y": Y})
                cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n")
                cl.send(resp.encode())

            # --- Все остальное ---
            else:
                cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n")
                cl.sendall(HTML.encode("utf-8"))

        except Exception as e:
            print("Ошибка:", e)
        finally:
            cl.close()

# --- Запуск ---
if __name__ == "__main__":
    try:
        ip = connect_wifi()  # сначала Wi-Fi
        serve(ip, 8082)      # затем сервер
    except KeyboardInterrupt:
        print("Сервер остановлен")
    except Exception as e:
        print("Fatal error:", e)
